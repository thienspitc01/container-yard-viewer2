
import React, { useMemo, useRef } from 'react';
import { Container } from '../types';
import { calculateTEU } from '../App';

// Declare html2canvas globally
declare const html2canvas: any;

interface DwellTimeStatisticsProps {
  containers: Container[];
}

const DwellTimeStatistics: React.FC<DwellTimeStatisticsProps> = ({ containers }) => {
  const reportRef = useRef<HTMLDivElement>(null);

  // Filter out the 'end' parts of 40' containers to avoid double counting
  const uniqueContainers = useMemo(() => {
    return containers.filter(c => !(c.isMultiBay && c.partType === 'end'));
  }, [containers]);

  const stats = useMemo(() => {
    // Condition for "valid" dwell time statistics (<= 90 days)
    const dwellLimit90 = (c: Container) => (c.dwellDays || 0) <= 90;

    // Helper to calculate a single row
    // We enforce that the Average calculation ONLY considers containers meeting dwellLimit90
    const calculateRow = (categoryFilter: (c: Container) => boolean) => {
        // 1. Base Population (All containers in this category) - For Inventory Counts
        const basePopulation = uniqueContainers.filter(categoryFilter);
        const count = basePopulation.length;
        const teus = basePopulation.reduce((sum, c) => sum + calculateTEU(c), 0);

        // 2. Target Population (Only containers <= 90 days) - For Average Dwell Calculation
        const targetPopulation = basePopulation.filter(dwellLimit90);
        const countUnder90 = targetPopulation.length;
        
        // Sum of days for ONLY the target population
        const totalDwellDaysOfTarget = targetPopulation.reduce((sum, c) => sum + (c.dwellDays || 0), 0);
        
        // Average = Sum(Target) / Count(Target)
        const avgDwell = countUnder90 > 0 ? totalDwellDaysOfTarget / countUnder90 : 0;

        // Return all stats. 
        // We pass 'totalDwellDaysOfTarget' and 'countUnder90' as 'totalDwell' and 'dwellPopCount' 
        // so that aggregateRows can sum them up correctly for weighted averages.
        return { 
            count, 
            teus, 
            avgDwell, 
            totalDwell: totalDwellDaysOfTarget, 
            dwellPopCount: countUnder90, 
            countUnder90 
        };
    };

    // Helper to aggregate multiple rows (Weighted Average Logic)
    const aggregateRows = (rows: ReturnType<typeof calculateRow>[]) => {
        const count = rows.reduce((acc, r) => acc + r.count, 0);
        const teus = rows.reduce((acc, r) => acc + r.teus, 0);
        const countUnder90 = rows.reduce((acc, r) => acc + r.countUnder90, 0);
        
        // Summing the total dwell days of the <=90 group from all rows
        const totalDwell = rows.reduce((acc, r) => acc + r.totalDwell, 0);
        // Summing the count of the <=90 group from all rows
        const dwellPopCount = rows.reduce((acc, r) => acc + r.dwellPopCount, 0);
        
        // Weighted Average = Total Days (of all <=90) / Total Count (of all <=90)
        const avgDwell = dwellPopCount > 0 ? totalDwell / dwellPopCount : 0;
        
        return { count, teus, avgDwell, totalDwell, dwellPopCount, countUnder90 };
    };

    // 1. Hàng nhập tàu (1)
    const row1 = calculateRow(c => c.detailedFlow === 'IMPORT' && c.status === 'FULL');

    // 2. Hàng nhập chuyển cảng (2)
    const row2 = calculateRow(c => c.detailedFlow === 'IMPORT STORAGE' && c.status === 'FULL');

    // 3. Hàng nhập (3) = (1) + (2)
    const row3 = aggregateRows([row1, row2]);

    // 4. Hàng xuất (4)
    const row4 = calculateRow(c => c.detailedFlow === 'EXPORT' && c.status === 'FULL');

    // 5. Container hàng (3) + (4)
    const row5 = aggregateRows([row3, row4]);

    // 6. Container rỗng
    const row6 = calculateRow(c => c.detailedFlow === 'STORAGE EMPTY' && c.status === 'EMPTY');

    // 7. Tổng (Total) = Row 5 + Row 6
    const rowTotal = aggregateRows([row5, row6]);

    return { row1, row2, row3, row4, row5, row6, rowTotal };
  }, [uniqueContainers]);

  const handleExport = async () => {
      if (reportRef.current && typeof html2canvas !== 'undefined') {
          try {
              const canvas = await html2canvas(reportRef.current, { scale: 2, backgroundColor: '#ffffff' });
              const image = canvas.toDataURL("image/png");
              const link = document.createElement('a');
              link.href = image;
              link.download = `Dwell_Time_Report_${new Date().toISOString().slice(0,10)}.png`;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
          } catch (e) {
              alert("Export failed");
          }
      } else {
          alert("Export not ready");
      }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200" ref={reportRef}>
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-800">Dwell Time Statistics</h2>
            <div className="flex items-center space-x-4">
                 <div className="text-xs text-slate-500 italic text-right">
                    <div className="font-bold text-blue-600">* Avg Dwell is calculated ONLY for containers ≤ 90 days.</div>
                    <div>* Count/TEUs reflect total inventory.</div>
                 </div>
                 <button 
                    onClick={handleExport}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center shadow"
                >
                    <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0l-4 4m4-4v12" />
                    </svg>
                    Export Image
                </button>
            </div>
        </div>

        <div className="overflow-x-auto border border-slate-300">
            <table className="w-full border-collapse">
                <thead>
                    <tr className="text-black font-bold text-sm">
                        <th className="bg-blue-200 border border-slate-400 p-3 w-1/4">Hướng</th>
                        <th className="bg-amber-400 border border-slate-400 p-3 w-1/3" colSpan={2}>Điều kiện</th>
                        <th className="bg-lime-400 border border-slate-400 p-3" colSpan={4}>Total</th>
                    </tr>
                    <tr className="bg-blue-100 text-slate-800 font-bold text-xs uppercase text-center">
                         <th className="border border-slate-400 p-2">Hướng</th>
                         <th className="border border-slate-400 p-2">Hướng (Detail)</th>
                         <th className="border border-slate-400 p-2 w-16">F/E</th>
                         <th className="border border-slate-400 p-2 w-24">Cont</th>
                         <th className="border border-slate-400 p-2 w-24 bg-yellow-100 text-yellow-900">Cont ≤ 90</th>
                         <th className="border border-slate-400 p-2 w-24">Teus</th>
                         <th className="border border-slate-400 p-2 w-24">Dwell time (Avg ≤ 90 days)</th>
                    </tr>
                </thead>
                <tbody className="text-sm text-slate-800">
                    {/* Row 1 */}
                    <tr className="bg-white hover:bg-slate-50">
                        <td className="border border-slate-300 p-2 font-medium">Hàng nhập tàu (1)</td>
                        <td className="border border-slate-300 p-2">IMPORT</td>
                        <td className="border border-slate-300 p-2 text-center">F</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row1.count.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center bg-yellow-50 font-medium text-slate-900">{stats.row1.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row1.teus.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center font-bold text-blue-700">{stats.row1.avgDwell.toFixed(1)}</td>
                    </tr>
                    {/* Row 2 */}
                    <tr className="bg-white hover:bg-slate-50">
                        <td className="border border-slate-300 p-2 font-medium">Hàng nhập chuyển cảng (2)</td>
                        <td className="border border-slate-300 p-2">IMPORT STORAGE</td>
                        <td className="border border-slate-300 p-2 text-center">F</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row2.count.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center bg-yellow-50 font-medium text-slate-900">{stats.row2.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row2.teus.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center font-bold text-blue-700">{stats.row2.avgDwell.toFixed(1)}</td>
                    </tr>
                    {/* Row 3 (Summary) */}
                    <tr className="bg-green-100 font-bold hover:bg-green-200">
                        <td className="border border-slate-300 p-2">Hàng nhập (3) = (1)+(2)</td>
                        <td className="border border-slate-300 p-2">IMPORT & IMPORT STORAGE</td>
                        <td className="border border-slate-300 p-2 text-center">F</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row3.count.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center bg-yellow-100 text-slate-900">{stats.row3.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row3.teus.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center font-bold text-blue-800">{stats.row3.avgDwell.toFixed(1)}</td>
                    </tr>
                    {/* Row 4 */}
                    <tr className="bg-white hover:bg-slate-50">
                        <td className="border border-slate-300 p-2 font-medium">Hàng xuất (4)</td>
                        <td className="border border-slate-300 p-2">EXPORT</td>
                        <td className="border border-slate-300 p-2 text-center">F</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row4.count.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center bg-yellow-50 font-medium text-slate-900">{stats.row4.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row4.teus.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center font-bold text-blue-700">{stats.row4.avgDwell.toFixed(1)}</td>
                    </tr>
                     {/* Row 5 (Summary) */}
                     <tr className="bg-blue-100 font-bold hover:bg-blue-200">
                        <td className="border border-slate-300 p-2">Container hàng (3) + (4)</td>
                        <td className="border border-slate-300 p-2">IMPORT... & EXPORT</td>
                        <td className="border border-slate-300 p-2 text-center">F</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row5.count.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center bg-yellow-100 text-slate-900">{stats.row5.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row5.teus.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center font-bold text-blue-800">{stats.row5.avgDwell.toFixed(1)}</td>
                    </tr>
                    {/* Row 6 */}
                    <tr className="bg-blue-200 font-medium hover:bg-blue-300">
                        <td className="border border-slate-300 p-2">Container rỗng</td>
                        <td className="border border-slate-300 p-2">STORAGE EMPTY</td>
                        <td className="border border-slate-300 p-2 text-center">E</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row6.count.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center bg-yellow-50 text-slate-900">{stats.row6.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center">{stats.row6.teus.toLocaleString()}</td>
                        <td className="border border-slate-300 p-2 text-center font-bold text-blue-800">{stats.row6.avgDwell.toFixed(1)}</td>
                    </tr>
                    {/* Total Row */}
                    <tr className="bg-slate-500 text-white font-bold text-base">
                        <td className="border border-slate-600 p-3 text-center" colSpan={3}>Tổng</td>
                        <td className="border border-slate-600 p-3 text-center">{stats.rowTotal.count.toLocaleString()}</td>
                        <td className="border border-slate-600 p-3 text-center text-yellow-300">{stats.rowTotal.countUnder90.toLocaleString()}</td>
                        <td className="border border-slate-600 p-3 text-center">{stats.rowTotal.teus.toLocaleString()}</td>
                        <td className="border border-slate-600 p-3 text-center font-bold">{stats.rowTotal.avgDwell.toFixed(1)}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default DwellTimeStatistics;
